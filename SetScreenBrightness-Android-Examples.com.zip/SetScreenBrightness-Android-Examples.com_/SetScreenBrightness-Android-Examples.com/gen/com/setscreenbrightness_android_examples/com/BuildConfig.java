/** Automatically generated file. DO NOT MODIFY */
package com.setscreenbrightness_android_examples.com;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}