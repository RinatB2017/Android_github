package com.echessa.videotube;

/**
 * Created by echessa on 1/13/17.
 */

public final class Config {

    private Config() {
    }

    public static final String YOUTUBE_API_KEY = "AIzaSyCG25IwSEZcJuF5Te7kko9XawkHaEJ48Ws";

}
