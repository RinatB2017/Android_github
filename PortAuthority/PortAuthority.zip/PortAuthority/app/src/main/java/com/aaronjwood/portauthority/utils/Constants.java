package com.aaronjwood.portauthority.utils;

/**
 * Class for storing some common constant values
 */
public class Constants {
    public static final int MAX_PORT_VALUE = 65535;
    public static final int MIN_PORT_VALUE = 1;
}
