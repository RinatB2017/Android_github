# http-request-android-app
a simple app that makes http connections for an endpoint you want and return the status code and the html content.

![png](https://github.com/testobject/http-request-android-app/blob/master/Screenshot.png)
