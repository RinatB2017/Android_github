# Auto Clicker

An Android App written in Kotlin to click on the screen automatically.

# DONE

* Auto click on a specific position

# TODO

* Permission request description
* Auto click setting
* Multi-Click
* Support gesture
* Action sequence
* Better UI
* Better readme
* And more